
package org.example.footballmanager.model.event;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import org.example.footballmanager.simulator.MatchContext;

@Getter
@Setter
@MappedSuperclass
public abstract class MatchEvent {

    @Column(name = "goal_minute", nullable = false)
    protected int minute;

    public abstract void apply(MatchContext context);
    public abstract String getDescription();
}
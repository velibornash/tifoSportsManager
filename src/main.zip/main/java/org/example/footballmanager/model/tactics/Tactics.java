package org.example.footballmanager.model.tactics;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Tactics {
    private double aggression;       // 0.0 – 2.0
    private double pressing;
    private double counterAttack;
    private double ballControl;

    public static Tactics defaultBalanced() {
        return new Tactics(1.0, 1.0, 1.0, 1.0);
    }
}
package org.example.footballmanager.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
public class Lineup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Team team;

    @ManyToOne
    @JoinColumn(name = "match_id")
    private Match match;

    @ManyToMany
    private List<Player> startingPlayers;

    @ManyToMany
    private List<Player> substitutes;

    private String formation; // npr: "4-4-2", "3-5-2"
}
package org.example.footballmanager.model;

import jakarta.persistence.*;
import lombok.Data;
import org.example.footballmanager.model.event.*;
import org.example.footballmanager.model.tactics.Tactics;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
public class Match {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Team homeTeam;

    @ManyToOne
    private Team awayTeam;

    @OneToOne
    private Lineup homeLineup;

    @OneToOne
    private Lineup awayLineup;

    private Integer homeGoals = 0;
    private Integer awayGoals = 0;

    private LocalDateTime matchDate;

    private String homeFormation;
    private String awayFormation;

    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<GoalEvent> goals = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<FreeKickEvent> freeKicks = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<ShotOnTargetEvent> shotsOnTarget = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<ShotOffTargetEvent> shotsOffTarget = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<PenaltyEvent> penalties = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<YellowCardEvent> yellowCards = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<RedCardEvent> redCards = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<ChanceEvent> chances = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<InjuryEvent> injuries = new ArrayList<>();
    @OneToMany(mappedBy = "match", cascade = CascadeType.ALL)
    private List<SubstitutionEvent> substitutions = new ArrayList<>();

    public List<GoalEvent> getGoalEvents() {
        return goals.stream()
                .filter(e -> e instanceof GoalEvent)
                .map(e -> (GoalEvent) e)
                .toList();
    }

    @Transient
    public List<MatchEvent> getAllMatchEvents() {
        List<MatchEvent> all = new ArrayList<>();
        all.addAll(goals);
        // Dodaj i ostale događaje
        all.addAll(freeKicks);
        all.addAll(shotsOnTarget);
        all.addAll(shotsOffTarget);
        all.addAll(penalties);
        all.addAll(yellowCards);
        all.addAll(redCards);
        all.addAll(chances);
        all.addAll(injuries);
        all.addAll(substitutions);
        return all;
    }
    private boolean played = false;
    @Transient
    private Tactics homeTactics = Tactics.defaultBalanced();

    @Transient
    private Tactics awayTactics = Tactics.defaultBalanced();
}
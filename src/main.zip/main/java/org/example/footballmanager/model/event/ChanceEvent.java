package org.example.footballmanager.model.event;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.example.footballmanager.model.Match;
import org.example.footballmanager.model.Player;
import org.example.footballmanager.model.Team;
import org.example.footballmanager.simulator.MatchContext;

import java.util.Random;

@Getter
@Setter
@Entity
public class ChanceEvent extends MatchEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Match match;

    @ManyToOne
    private Team team;

    @ManyToOne
    private Player creator;

    @Override
    public void apply(MatchContext context) {
        context.getMatch().getChances().add(this);
    }
    private static final String[] chanceTypes = {
            "dribling", "centaršut", "dupli pas", "solo prodor", "ubacivanje iz auta"
    };

    @Override
    public String getDescription() {
        String type = chanceTypes[new Random().nextInt(chanceTypes.length)];
        return String.format("%d' Šansa (%s) - %s", minute, type, creator.getName());
    }
}
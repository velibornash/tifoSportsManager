package org.example.footballmanager;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.example.footballmanager.model.*;
import org.example.footballmanager.repository.*;
import org.example.footballmanager.service.MatchService;
import org.example.footballmanager.util.PlayerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final TeamRepository teamRepository;
    private final PlayerRepository playerRepository;
    private final MatchRepository matchRepository;
    private final LineupRepository lineupRepository;
    private final MatchService matchService;

    @Override
    @Transactional
    public void run(String... args) {
        Team omladinac = new Team();
        omladinac.setName("Omladinac");
        omladinac.setCountry("Srbija");
        teamRepository.save(omladinac);

        Team trefa = new Team();
        trefa.setName("2Trefa");
        trefa.setCountry("Srbija");
        teamRepository.save(trefa);

        List<Player> omladinacPlayers = PlayerFactory.createOmladinacPlayers(omladinac);
        playerRepository.saveAll(omladinacPlayers);

        List<Player> trefaPlayers = PlayerFactory.createRandomTeamPlayers("2Trefa", trefa);
        playerRepository.saveAll(trefaPlayers);

        Lineup lineup1 = new Lineup();
        lineup1.setTeam(omladinac);
        lineup1.setStartingPlayers(new ArrayList<>(omladinacPlayers.subList(0, 11)));
        lineupRepository.save(lineup1);

        Lineup lineup2 = new Lineup();
        lineup2.setTeam(trefa);
        lineup2.setStartingPlayers(new ArrayList<>(trefaPlayers.subList(0, 11)));
        lineupRepository.save(lineup2);

        Match match = new Match();
        match.setHomeTeam(omladinac);
        match.setAwayTeam(trefa);
        match.setHomeFormation("3-2-2-3");
        match.setAwayFormation("4-4-2");
        match.setMatchDate(LocalDateTime.now());
        match.setHomeLineup(lineup1);
        match.setAwayLineup(lineup2);
        matchRepository.save(match);

        Match played = matchService.playMatch(match.getId());

        matchService.printMatchDetails(played);
    }
}
package org.example.footballmanager.simulator;

import org.example.footballmanager.model.Player;
import org.example.footballmanager.model.Position;

import java.util.Random;

public class DuelCalculator {

    private static final Random random = new Random();

    public static boolean winDuel(Player attacker, Player defender) {
        double attackScore = getAttackScore(attacker);
        double defenseScore = getDefenseScore(defender);

        double probability = attackScore / (attackScore + defenseScore);

        return random.nextDouble() < probability;
    }

    private static double getAttackScore(Player player) {
        double score = 0;
        score += player.getSkills().getPace() * 1.2;
        score += player.getSkills().getTechnique() * 1.5;
        score += player.getSkills().getStriker() * 2.0;
        score += player.getSkills().getPassing() * 0.5;
        score += player.getForm();
        return score;
    }

    private static double getDefenseScore(Player player) {
        double score = 0;
        score += player.getSkills().getDefender() * 2.0;
        score += player.getSkills().getPace();
        score += player.getSkills().getPlaymaker();
        score += player.getSkills().getTechnique() * 0.5;
        score += player.getForm();
        return score;
    }
}
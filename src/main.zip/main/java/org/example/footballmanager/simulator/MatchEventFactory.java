package org.example.footballmanager.simulator;

import lombok.RequiredArgsConstructor;
import org.example.footballmanager.model.Match;
import org.example.footballmanager.model.Player;
import org.example.footballmanager.model.Position;
import org.example.footballmanager.model.Team;
import org.example.footballmanager.model.event.*;
import org.example.footballmanager.model.tactics.Formation;
import org.example.footballmanager.repository.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Random;

@Component
@RequiredArgsConstructor
public class MatchEventFactory {

    private final GoalEventRepository goalEventRepository;
    private final ShotOnTargetEventRepository shotOnTargetRepo;
    private final ShotOffTargetEventRepository shotOffTargetRepo;
    private final YellowCardEventRepository yellowCardRepo;
    private final RedCardEventRepository redCardRepo;
    private final FreeKickEventRepository freeKickRepo;
    private final PenaltyEventRepository penaltyRepo;
    private final ChanceEventRepository chanceRepo;
    private final InjuryEventRepository injuryRepo;

    private final Random random = new Random();

    public MatchEvent createRandomEvent(MatchContext context, List<Player> homePlayers, List<Player> awayPlayers)
    {
        int minute = context.getCurrentMinute();
        Match match = context.getMatch();

        double homeStrength = TeamStrengthCalculator.calculateTeamStrength(
                homePlayers,
                Formation.fromString(match.getHomeFormation()),
                match.getHomeTactics(),
                true);

        double awayStrength = TeamStrengthCalculator.calculateTeamStrength(
                awayPlayers,
                Formation.fromString(match.getAwayFormation()),
                match.getAwayTactics(),
                false);

        double homeChance = homeStrength * context.getHomeMomentum();
        double awayChance = awayStrength * context.getAwayMomentum();

        double total = homeChance + awayChance;
        boolean isHome = random.nextDouble() < (homeChance / total);

        Team team = isHome ? match.getHomeTeam() : match.getAwayTeam();
        List<Player> teamPlayers = isHome ? homePlayers : awayPlayers;

        double roll = random.nextDouble();
        MatchEvent event;

        if (roll < 0.05) {
            event = createGoal(match, team, teamPlayers, minute);
        } else if (roll < 0.12) {
            event = createShotOnTarget(match, team, teamPlayers, minute);
        } else if (roll < 0.20) {
            event = createShotOffTarget(match, team, teamPlayers, minute);
        } else if (roll < 0.25) {
            event = createYellowCard(match, teamPlayers, minute);
        } else if (roll < 0.27) {
            event = createRedCard(match, teamPlayers, minute);
        } else if (roll < 0.32) {
            event = createFreeKick(match, team, teamPlayers, minute);
        } else if (roll < 0.35) {
            event = createPenalty(match, team, teamPlayers, minute);
        } else if (roll < 0.40) {
            event = createChance(match, team, teamPlayers, minute);
        } else if (roll < 0.42) {
            event = createInjury(match, teamPlayers, minute);
        } else {
            return null;
        }

        if (event != null) {
            event.setMinute(minute);
            event.apply(context);
            //saveEvent(event);
        }

        return event;
    }

    private void saveEvent(MatchEvent event) {
        if (event instanceof GoalEvent e) goalEventRepository.save(e);
        else if (event instanceof ShotOnTargetEvent e) shotOnTargetRepo.save(e);
        else if (event instanceof ShotOffTargetEvent e) shotOffTargetRepo.save(e);
        else if (event instanceof YellowCardEvent e) yellowCardRepo.save(e);
        else if (event instanceof RedCardEvent e) redCardRepo.save(e);
        else if (event instanceof FreeKickEvent e) freeKickRepo.save(e);
        else if (event instanceof PenaltyEvent e) penaltyRepo.save(e);
        else if (event instanceof ChanceEvent e) chanceRepo.save(e);
        else if (event instanceof InjuryEvent e) injuryRepo.save(e);
    }

    private GoalEvent createGoal(Match match, Team team, List<Player> players, int minute) {
        Player scorer = randomPlayer(players);
        Player assistant = random.nextBoolean() ? randomOther(players, scorer) : null;

        GoalEvent goal = new GoalEvent();
        goal.setMatch(match);
        goal.setTeam(team);
        goal.setScorer(scorer);
        goal.setAssistant(assistant);
        goal.setMinute(minute);
        return goal;
    }

    private ShotOnTargetEvent createShotOnTarget(Match match, Team team, List<Player> players, int minute) {
        ShotOnTargetEvent e = new ShotOnTargetEvent();
        e.setMatch(match);
        e.setTeam(team);
        e.setShooter(randomPlayer(players));
        e.setMinute(minute);
        return e;
    }

    private ShotOffTargetEvent createShotOffTarget(Match match, Team team, List<Player> players, int minute) {
        ShotOffTargetEvent e = new ShotOffTargetEvent();
        e.setMatch(match);
        e.setTeam(team);
        e.setShooter(randomPlayer(players));
        e.setMinute(minute);
        return e;
    }

    private YellowCardEvent createYellowCard(Match match, List<Player> players, int minute) {
        YellowCardEvent e = new YellowCardEvent();
        e.setMatch(match);
        e.setPlayer(randomPlayer(players));
        e.setMinute(minute);
        return e;
    }

    private RedCardEvent createRedCard(Match match, List<Player> players, int minute) {
        RedCardEvent e = new RedCardEvent();
        e.setMatch(match);
        e.setPlayer(randomPlayer(players));
        e.setMinute(minute);
        return e;
    }

    private FreeKickEvent createFreeKick(Match match, Team team, List<Player> players, int minute) {
        FreeKickEvent e = new FreeKickEvent();
        e.setMatch(match);
        e.setTeam(team);
        e.setTaker(randomNonGoalkeeper(players));
        e.setMinute(minute);
        return e;
    }

    private PenaltyEvent createPenalty(Match match, Team team, List<Player> players, int minute) {
        PenaltyEvent e = new PenaltyEvent();
        e.setMatch(match);
        e.setTeam(team);
        e.setTaker(randomNonGoalkeeper(players));
        e.setScored(random.nextBoolean());
        e.setMinute(minute);
        return e;
    }

    private ChanceEvent createChance(Match match, Team team, List<Player> players, int minute) {
        ChanceEvent e = new ChanceEvent();
        e.setMatch(match);
        e.setTeam(team);
        e.setCreator(randomPlayer(players));
        e.setMinute(minute);
        return e;
    }

    private InjuryEvent createInjury(Match match, List<Player> players, int minute) {
        InjuryEvent e = new InjuryEvent();
        e.setMatch(match);
        e.setInjuredPlayer(randomPlayer(players));
        e.setMinute(minute);
        return e;
    }

    private Player randomPlayer(List<Player> players) {
        return players.get(random.nextInt(players.size()));
    }

    private Player randomOther(List<Player> players, Player exclude) {
        Player p;
        do {
            p = players.get(random.nextInt(players.size()));
        } while (p.equals(exclude));
        return p;
    }

    private Player randomNonGoalkeeper(List<Player> players) {
        List<Player> fieldPlayers = players.stream()
                .filter(p -> !Objects.equals(p.getPosition(), Position.GK))
                .toList();
        return fieldPlayers.get(random.nextInt(fieldPlayers.size()));
    }
}
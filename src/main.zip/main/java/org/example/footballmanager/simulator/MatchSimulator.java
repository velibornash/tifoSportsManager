// simulator/MatchSimulator.java

package org.example.footballmanager.simulator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.footballmanager.model.Match;
import org.example.footballmanager.model.Player;
import org.example.footballmanager.model.event.MatchEvent;
import org.example.footballmanager.model.event.SubstitutionEvent;
import org.example.footballmanager.model.tactics.Formation;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;

@Slf4j
@Component
@RequiredArgsConstructor
public class MatchSimulator {

    private final MatchEventFactory eventFactory;
    private final Random random = new Random();

    public void simulateMatch(Match match, List<Player> homePlayers, List<Player> awayPlayers) {
        MatchContext context = new MatchContext(match);

        for (int minute = 1; minute <= 90; minute++) {
            context.setCurrentMinute(minute);

            if (random.nextDouble() < eventProbability(match, context)) {
                MatchEvent event = eventFactory.createRandomEvent(context, homePlayers, awayPlayers);
            }

/*           if (minute == 60 || minute == 75) {
                performSubstitution(match, context, homePlayers, true);
                performSubstitution(match, context, awayPlayers, false);
            }*/
        }
    }

    private void performSubstitution(Match match, MatchContext context, List<Player> teamPlayers, boolean isHomeTeam) {
      //  if (teamPlayers.size() < 12) return;

        Player out = teamPlayers.get(random.nextInt(11));
        Player in = teamPlayers.get(random.nextInt(4) + 11);

        SubstitutionEvent sub = new SubstitutionEvent();
        sub.setMatch(match);
        sub.setMinute(context.getCurrentMinute());
        sub.setPlayerOut(out);
        sub.setPlayerIn(in);

        sub.apply(context); // ✅ OBAVEZNO!

        log.info("[{}'] {}", context.getCurrentMinute(), sub.getDescription());

        // Zameni igrača u listi startera
        teamPlayers.remove(out);
        teamPlayers.add(in);
    }

    private double eventProbability(Match match, MatchContext context) {
        double homeStrength = TeamStrengthCalculator.calculateTeamStrength(
                match.getHomeLineup().getStartingPlayers(),
                Formation.fromString(match.getHomeFormation()),
                match.getHomeTactics(), true
        );
        double awayStrength = TeamStrengthCalculator.calculateTeamStrength(
                match.getAwayLineup().getStartingPlayers(),
                Formation.fromString(match.getAwayFormation()),
                match.getAwayTactics(), false
        );

        double base = 0.1;
        double strengthFactor = (homeStrength + awayStrength) / 300.0;
        return Math.min(0.3, base + strengthFactor);
    }
}